import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CarDetails } from '../CarDetails';
import { carsListingApiService } from '../cars-listing-api-service';

@Component({
  selector: 'app-car-info',
  templateUrl: './car-info.component.html',
  styleUrls: ['./car-info.component.css']
})
export class CarInfoComponent implements OnInit {
  car: CarDetails = { id: '', listingType: '', odometer: 0,price:0, sellerType: '', state: '',title:'',features:[],photos:[]};
  isLoadingResults = true;
  id: string;
  private sub: any;
  constructor(private route: ActivatedRoute, private api: carsListingApiService) { }

  ngOnInit(): void {
    this.sub = this.route.params.subscribe(params => {
      this.id = params['id']; 
      this.getCarDetails(this.id);
   });
  }
  getCarDetails(id) {
    this.api.getCar(id)
      .subscribe(data => {
        this.car = data;
        console.log(this.car);
        this.isLoadingResults = false;
      });
  }
}

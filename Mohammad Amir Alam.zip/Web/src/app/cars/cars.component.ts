import { Component, OnInit } from '@angular/core';
import { CarSummary } from '../CarSummary';
import { carsListingApiService } from '../cars-listing-api-service';

@Component({
  selector: 'app-cars',
  templateUrl: './cars.component.html',
  styleUrls: ['./cars.component.css']
})
export class CarsComponent implements OnInit {
  data: CarSummary[] = [];
  isLoadingResults = true;
  constructor(private api: carsListingApiService) { }

  ngOnInit(): void {
    this.api.getCarsListing()
    .subscribe(res => {
      this.data = res;
      console.log(this.data);
      this.isLoadingResults = false;
    }, err => {
      console.log(err);
      this.isLoadingResults = false;
    });
  }

}

import { Injectable } from '@angular/core';
import { Observable, of, throwError } from 'rxjs';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { catchError, tap, map } from 'rxjs/operators';
import{ErrorResponse} from './Error';
import { CarSummary } from './CarSummary';
import { CarDetails } from './CarDetails';
const httpOptions = {
  headers: new HttpHeaders({'Content-Type': 'application/json'})
};
const apiUrl = "https://localhost:5001/cars";
@Injectable({
  providedIn: 'root'
})
export class carsListingApiService {
  constructor(private http: HttpClient) { }

  getCarsListing (): Observable<CarSummary[]> {
    const url = `${apiUrl}`;
    return this.http.get<CarSummary[]>(apiUrl)
      .pipe(
        tap(heroes => console.log('fetched Car Listing')),
        catchError(this.handleError('getCarsListing'))
      );
  }
  getCar(id: string): Observable<CarDetails> {
    const url = `${apiUrl}/${id}`;
    return this.http.get<CarDetails>(url).pipe(
      tap(_ => console.log(`fetched Car id=${id}`)),
      catchError(this.handleError(`getCar id=${id}`))
    );
  }
  private handleError (operation = 'operation') {
    return (error: any) => {
      console.log(error.error);
      throw(error.error as ErrorResponse);
    };
  }
}

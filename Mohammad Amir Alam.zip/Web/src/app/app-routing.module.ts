import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CarsComponent } from './cars/cars.component';
import { CarDetails } from './CarDetails';
import { CarInfoComponent } from './car-info/car-info.component';

export const routes: Routes = [
  {
    path: '',
    component: CarsComponent,
    data: { title: 'List of Cars' }
  },
  {
    path: 'cars/:id',
    component: CarInfoComponent,
    data: { title: 'Car info' }
  },
  {
    path: 'cars',
    component: CarsComponent,
    data: { title: 'List of Cars' }
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

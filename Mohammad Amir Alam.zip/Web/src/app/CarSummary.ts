export class CarSummary {
    id:          string;
    listingType: string;
    odometer:    number;
    title:       string;
    state:       string;
    price:       number;
    sellerType:  string;
    photo:       string;
}

export class CarDetails {
    id:          string;
    listingType: string;
    odometer:    number;
    title:       string;
    state:       string;
    price:       number;
    sellerType:  string;
    features:    Feature[];
    photos:      string[];
}

export class Feature {
    name:  string;
    group: string;
}

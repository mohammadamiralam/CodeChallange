﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CarGallery.API.Models;
using CarsGallery.Service.Contracts;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace CarsGallery.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class CarsController : ControllerBase
    {
        private readonly ILogger<CarsController> _logger;
        private readonly ICarsListingHandler _carsListingHandler;
        public CarsController(ILogger<CarsController> logger, ICarsListingHandler carsListingHandler)
        {
            _logger = logger;
            _carsListingHandler = carsListingHandler;
        }

        [HttpGet]
        public async Task<IEnumerable<CarSummary>> GetAll()
        {
            return await _carsListingHandler.GetAll();
        }
        [HttpGet("{carId}")]
        public async Task<ActionResult<CarInfo>> GetById([FromRoute] string carId)
        {
            var details= await _carsListingHandler.GetById(carId);
            if (details == null)
                return NotFound();
            return details;
        }
    }
}

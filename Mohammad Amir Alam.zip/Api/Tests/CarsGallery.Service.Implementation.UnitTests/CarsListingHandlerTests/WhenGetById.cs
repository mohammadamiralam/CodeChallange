﻿using CarGallery.API.Models;
using CarsGallery.Service.Contracts;
using CarsGallery.Service.Contracts.Models;
using Moq;
using NUnit.Framework;
using NUnit.Framework.Interfaces;
using System.Linq;

namespace CarsGallery.Service.Implementation.UnitTests.CarsListingHandlerTests
{
    [TestFixture]
    public class WhenGetById
    {
        private Mock<ICarsListingClient> mockCarsListingClient;
        private CarDetails carDetails;
        private string carId = "id";
        private CarsListingHandler handler;
        [SetUp]
        public void Setup()
        {
            carDetails = new CarDetails()
            {
                Id = "1",
                ListingType = "type1",
                Photo = "link1"
            };
            mockCarsListingClient = new Mock<ICarsListingClient>();
            mockCarsListingClient.Setup(x => x.GetCarById(It.Is<string>(x => x == carId))).ReturnsAsync(carDetails);
            handler = new CarsListingHandler(mockCarsListingClient.Object);
        }
        [Test]
        public void Then_GetCarById_Method_Should_Be_Called_Once_With_SameId()
        {
            var result = handler.GetById(carId).Result;
            mockCarsListingClient.Verify(x => x.GetCarById(It.Is<string>(x => x == carId)), Times.Once);
        }
        [Test]
        public void Then_GetCarById_Should_Return_Item_Obtained_From_Api()
        {
            var result = handler.GetById(carId).Result;
            Assert.AreEqual(result, carDetails);
        }
        [Test]
        public void Then_GetCarById_Should_Return_Null_When_ID_Not_Found()
        {
            var result = handler.GetById("any").Result;
            Assert.AreEqual(result, null);
        }
    }
}

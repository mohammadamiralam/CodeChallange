﻿using CarGallery.API.Models;
using CarsGallery.Service.Contracts;
using CarsGallery.Service.Contracts.Models;
using Moq;
using NUnit.Framework;
using NUnit.Framework.Interfaces;
using System.Linq;

namespace CarsGallery.Service.Implementation.UnitTests.CarsListingHandlerTests
{
    [TestFixture]
    public class WhenGetAll
    {
        private Mock<ICarsListingClient> mockCarsListingClient;
        private CarsListing carsListing;
        private CarsListingHandler handler;
        [SetUp]
        public void Setup()
        {
            carsListing = new CarsListing()
            {
                Items = new System.Collections.Generic.List<CarSummary>()
            {
                new CarSummary()
                {
                    Id="1",
                    ListingType="type1",
                    Photo="link1"
                },
                new CarSummary()
                {
                    Id="2",
                    ListingType="type2",
                    Photo="link2"
                },
            }
            };
            mockCarsListingClient = new Mock<ICarsListingClient>();
            mockCarsListingClient.Setup(x => x.GetCarsListing()).ReturnsAsync(carsListing);
            handler = new CarsListingHandler(mockCarsListingClient.Object);
        }
        [Test]
        public void Then_CarsListing_Method_Should_Be_Called_Once()
        {
            var result = handler.GetAll().Result;
            mockCarsListingClient.Verify(x => x.GetCarsListing(), Times.Once);
        }
        [Test]
        public void Then_CarsListing_Should_Return_Items_Obtained_From_Api()
        {
            var result = handler.GetAll().Result;
            Assert.AreEqual(result.Count(), carsListing.Items.Count);
            foreach (var car in carsListing.Items)
            {
                Assert.IsTrue(result.Contains(car));
            }
        }
    }
}

﻿using System.Collections.Generic;
using System.Threading.Tasks;
using CarsGallery.Service.Contracts.Models;
using Refit;

namespace CarsGallery.Service.Contracts
{
    public interface ICarsListingClient
    {


        [Get("/cars/listings")]
        [Headers("Authorization: Basic")]
        Task<CarsListing> GetCarsListing();

        [Get("/cars/details/{car-id}")]
        [Headers("Authorization: Basic")]
        Task<CarDetails> GetCarById([AliasAs("car-id")] string carId);

    }
}

﻿using CarGallery.API.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CarsGallery.Service.Contracts
{
    public interface ICarsListingHandler
    {
        Task<List<CarSummary>> GetAll();
        Task<CarInfo> GetById(string id);
    }
}

﻿namespace CarsGallery.Service.Contracts
{
    public class CarFeature
    {
        public string Name { get; set; }
        public string Group { get; set; }
    }

}

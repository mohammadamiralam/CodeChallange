﻿using CarGallery.API.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace CarsGallery.Service.Contracts
{
    public class CarDetails:CarSummary
    {
        public List<CarFeature> Features { get; set; }
        public List<string> Photos { get; set; }
    }

}

﻿using CarGallery.API.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace CarsGallery.Service.Contracts.Models
{
    public class CarsListing
    {
        public List<CarSummary> Items { get; set; }
    }
}

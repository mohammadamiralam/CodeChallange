﻿using CarGallery.API.Models;
using CarsGallery.Service.Contracts;
using Refit;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CarsGallery.Service.Implementation
{
    public class CarsListingHandler : ICarsListingHandler
    {
        private readonly ICarsListingClient _client;
        public CarsListingHandler(ICarsListingClient client)
        {
            _client = client;
        }

        public async Task<List<CarSummary>> GetAll()
        {
            var carsListing = await _client.GetCarsListing();
            return carsListing.Items;
        }

        public async Task<CarInfo> GetById(string id)
        {
            try
            {
                var details = await _client.GetCarById(id);
                if (details == null)
                    return null;
                return new CarInfo()
                {
                    Id = details.Id,
                    ListingType = details.ListingType,
                    Odometer = details.Odometer,
                    Photo = details.Photo,
                    Price = details.Price,
                    SellerType = details.SellerType,
                    State = details.State,
                    Title = details.Title,
                    Photos = details.Photos,
                    Features = details.Features?.GroupBy(x => x.Group).Select(x => new CarFeatureInfo()
                    {
                        Group = x.Key,
                        Info = x.Select(y => y.Name).ToList()
                    }).ToList()
                };
            }
            catch (Exception ex)
            {
                var apiException = ex as ApiException;
                if (apiException.StatusCode == System.Net.HttpStatusCode.NotFound || apiException.StatusCode == System.Net.HttpStatusCode.BadGateway)
                    return null;
                throw;
            }
        }
    }
}

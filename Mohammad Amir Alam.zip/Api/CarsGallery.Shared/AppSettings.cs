﻿using System;

namespace CarsGallery.Shared
{
    public class AppSettings
    {
        public CarsListingApiSettings CarsListingApiSettings { get; set; }
    }
}

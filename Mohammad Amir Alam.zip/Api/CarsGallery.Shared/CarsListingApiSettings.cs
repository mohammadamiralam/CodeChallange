﻿namespace CarsGallery.Shared
{
    public class CarsListingApiSettings
    {
        public string BaseUrl { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
    }
}

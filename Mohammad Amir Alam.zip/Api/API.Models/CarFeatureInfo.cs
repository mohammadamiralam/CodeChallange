﻿using System.Collections.Generic;

namespace CarGallery.API.Models
{
    public class CarFeatureInfo
    {
        public CarFeatureInfo()
        {
            Info = new List<string>();
        }
        public string Group { get; set; }
        public List<string> Info { get; set; }
    }

}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CarGallery.API.Models
{
    public class CarInfo:CarSummary
    {
        public List<CarFeatureInfo> Features { get; set; }
        public List<string> Photos { get; set; }
    }
}

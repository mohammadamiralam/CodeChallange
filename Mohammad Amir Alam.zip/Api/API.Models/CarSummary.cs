﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CarGallery.API.Models
{
    public class CarSummary
    {
        public string Id { get; set; }
        public string ListingType { get; set; }
        public int Odometer { get; set; }
        public string Title { get; set; }
        public string State { get; set; }
        public int Price { get; set; }
        public string SellerType { get; set; }
        public string Photo { get; set; }
        public override bool Equals(object obj)
        {
            if (obj == null || (obj as CarSummary) == null)
                return base.Equals(obj);
            var summary = obj as CarSummary;
            return this.Id == summary.Id &&
                this.ListingType == summary.ListingType &&
                this.Odometer == summary.Odometer &&
                this.Photo == summary.Photo &&
                this.Price == summary.Price &&
                this.SellerType == summary.SellerType &&
                this.State == summary.State &&
                this.Title == summary.Title;
        }
    }

}

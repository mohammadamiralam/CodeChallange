
# Running Application Locally
## Api
To Run Api using CMD you need to go to /Api/CarsGallery directory and run:
```
dotnet run
```

## Web
To Run Web using CMD you need to go to /Web directory and run:
```
npm install
```
and then from /Web/src directory run:
```
ng serve
```

## Assumptions:
By default when running the application locally Api will be available on https://localhost:5001 so Web is configured to contact with that address.
To change it you need to go to /Web/src/app/cars-listing-api-service.ts and update variable 'apiUrl'